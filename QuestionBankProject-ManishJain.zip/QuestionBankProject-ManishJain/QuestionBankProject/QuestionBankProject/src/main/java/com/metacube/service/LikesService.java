/**
 * 
 */
package com.metacube.service;

import java.util.List;
import java.util.Map;

import com.metacube.exception.QuestionBankException;
import com.metacube.exception.QuestionBankSystemException;
import com.metacube.model.Likes;

/**
 * @author Team MJ LikesService.Java :for like on question and answer
 */
public interface LikesService {

	/**
	 * @param likes
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void add(Likes likes) throws QuestionBankSystemException,
			QuestionBankException;

	/**
	 * @param likes
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void merge(Likes likes) throws QuestionBankSystemException,
			QuestionBankException;

	/**
	 * @param likes
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void edit(Likes likes) throws QuestionBankSystemException,
			QuestionBankException;

	/**
	 * @param likeId
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void delete(int likeId) throws QuestionBankSystemException,
			QuestionBankException;

	/**
	 * @param likeId
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Likes getLike(int likeId) throws QuestionBankSystemException,
			QuestionBankException;

	/**
	 * @param userId
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Likes> getLikeByUserId(int userId)
			throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param questionAnswerId
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Likes> getLikeByQuestionAnswerId(int questionAnswerId)
			throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param likeOn
	 * @param questionAnswerId
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public int getLikeOn(boolean likeOn, int questionAnswerId)
			throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param likeOn
	 * @param questionAnswerId
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public int getDislikeOn(boolean likeOn, int questionAnswerId)
			throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param questionAnswerId
	 * @param userId
	 * @param onLike
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Likes> isLike(int questionAnswerId, int userId, boolean onLike)
			throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param userId
	 * @param questionId
	 * @param questionAnswerId
	 * @param isLike
	 * @param onLike
	 * @param map
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String, Object> liker(int userId, int questionId,
			int questionAnswerId, boolean isLike, boolean onLike,
			Map<String, Object> map) throws QuestionBankSystemException,
			QuestionBankException;

	/**
	 * @param questionId
	 * @param map
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String, Object> closeQuestion(int questionId,
			Map<String, Object> map) throws QuestionBankSystemException,
			QuestionBankException;

	/**
	 * @param questionId
	 * @param map
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String, Object> verifyAnswer(int questionId, int answerId,
			Map<String, Object> map) throws QuestionBankSystemException,
			QuestionBankException;
}
