/**
 * 
 */
package com.metacube.service;

import java.util.List;
import java.util.Map;

import org.springframework.validation.BindingResult;

import com.metacube.exception.QuestionBankException;
import com.metacube.exception.QuestionBankSystemException;
import com.metacube.model.Question;
import com.metacube.model.User;

/**
 * @author Team MJ QuestionService :for posting question 
 */
public interface QuestionService {
	/**Function to add question
	 * @param question
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void add(Question question) throws QuestionBankSystemException, QuestionBankException;
	/**Function to edit question
	 * @param question
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void edit(Question question) throws QuestionBankSystemException, QuestionBankException;
	/**Function to delete question based on its id
	 * @param questionId
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void delete(int questionId) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param questionId
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Question getQuestion(int questionId) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param tags
	 * @param startIndex
	 * @param numberOfRecordsPerPage
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Question> getQuestionsByTagId(String[] tags,int startIndex,int numberOfRecordsPerPage ) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param tags
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List getRecordCountForPagination(String[] tags) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param user
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Question> getQuestionsbyUserId(User user) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Question> getFrequentQuestions() throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Question> getAllQuestion() throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param user
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Question getLastQuestion(User user) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param map
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String,Object> getPostQuestion(Map<String, Object> map) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param questionId
	 * @param map
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String,Object> getEditQuestion(int questionId, Map<String, Object> map) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param questionId
	 * @param map
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String,Object> getQuestion(int questionId,Map<String, Object> map) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param postQuestion
	 * @param result
	 * @param questionTag
	 * @param action
	 * @param questionId
	 * @param map
	 * @param id
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String,Object> doActions( Question postQuestion, BindingResult result, String questionTag, String action, Integer questionId, Map<String, Object> map, int id) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param search
	 * @param action
	 * @param relatedTag
	 * @param map
	 * @param page
	 * @param numberOfRecordsPerPage
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String, Object> searchQuestion(String search, Integer action, String relatedTag, Map<String, Object> map,int page,int numberOfRecordsPerPage) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param startIndex
	 * @param numberOfRecordsPerPage
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Question> getFrequentQuestionsForPagination(int startIndex,int numberOfRecordsPerPage) throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Integer> getRecordCount() throws QuestionBankSystemException, QuestionBankException;
	/**
	 * @param startIndex
	 * @param numberOfRecordsPerPage
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Question> getQuestionForPagination(int startIndex,int numberOfRecordsPerPage ) throws QuestionBankSystemException, QuestionBankException;
}
