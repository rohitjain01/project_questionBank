/**
 * 
 */
package com.metacube.service;

import java.util.List;
import java.util.Map;

import com.metacube.exception.QuestionBankException;
import com.metacube.exception.QuestionBankSystemException;
import com.metacube.model.Answer;
import com.metacube.model.Question;
import com.metacube.model.User;

/**
 * @author Team MJ AnswerService.Java : works for posting answr
 */
public interface AnswerService {
	/**
	 * @param answer
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void add(Answer answer) throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param answer
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void edit(Answer answer) throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param answerId
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public void delete(int answerId) throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param answerId
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Answer getAnswer(int answerId) throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param question
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Answer> getAnswersbyQuestionId(Question question) throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param user
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Answer> getAnswersbyUserId(User user) throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public List<Answer> getAllAnswer() throws QuestionBankSystemException, QuestionBankException;

	/**
	 * @param answer
	 * @param isError
	 * @param questionId
	 * @param name
	 * @param email
	 * @param action
	 * @param map
	 * @param id
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String, Object> postAnswer(Answer answer, boolean isError,
			int questionId, String name, String email, String action,
			Map<String, Object> map, int id) throws QuestionBankSystemException, QuestionBankException;
	
	/**
	 * @param questionId
	 * @param map
	 * @return
	 * @throws QuestionBankSystemException
	 * @throws QuestionBankException
	 */
	public Map<String, Object> getDescriptionsAboutQuestionAnswer(int questionId, Map<String, Object> map) throws QuestionBankSystemException, QuestionBankException;

}
